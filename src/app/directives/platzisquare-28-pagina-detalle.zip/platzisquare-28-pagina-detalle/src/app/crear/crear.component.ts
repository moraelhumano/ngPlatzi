import { Component } from '@angular/core';

@Component({
    selector: 'app-crear',
    templateUrl: './crear.component.html'
})
export class CrearComponent {
    lugar:any = {};
    constructor(){

    }
    guardarLugar(){
    }
}